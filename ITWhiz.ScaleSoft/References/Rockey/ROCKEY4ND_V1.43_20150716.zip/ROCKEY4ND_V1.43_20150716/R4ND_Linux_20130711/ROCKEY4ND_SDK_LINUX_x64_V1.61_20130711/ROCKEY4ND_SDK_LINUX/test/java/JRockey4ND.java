package rockey;
public class JRockey4ND
{
	//static {System.loadLibrary("JRockey4ND");}			//For jdk-1.3
	static {System.load("/usr/local/lib/libJRockey4ND.so");}
	public native short Rockey(short func, short[] handle, int[] lp1, int[]	lp2, short[] p1,
					 short[] p2, short[] p3, short[] p4, byte[] buffer);
	public short RY_FIND=1;			
	public short RY_FIND_NEXT=2;	
	public short RY_OPEN=3;       
	public short RY_CLOSE=4;     
	public short RY_READ=5;	
	public short RY_WRITE=6;
	public short RY_RANDOM=7;
	public short RY_SEED=8;		
	public short RY_WRITE_USERID=9;
	public short RY_READ_USERID=10;
	public short RY_SET_MODULE=11;	
	public short RY_CHECK_MODULE=12;
	public short RY_WRITE_ARITHMETIC=13;
	public short RY_CALCULATE1=14;	
	public short RY_CALCULATE2=15;	
	public short RY_CALCULATE3=16;
	public short RY_DECREASE=17;

	
	public short  ERR_SUCCESS=0;		
	public short  ERR_NO_PARALLEL_PORT=1;
	public short  ERR_NO_DRIVER=2;	
	public short  ERR_NO_ROCKEY=3;
	public short  ERR_INVALID_PASSWORD=4;		
	public short  ERR_INVALID_PASSWORD_OR_ID=5;
	public short  ERR_SETID=6;               
	public short  ERR_INVALID_ADDR_OR_SIZE=7;
	public short  ERR_UNKNOWN_COMMAND=8;	
	public short  ERR_NOTBELEVEL3=9;
	public short  ERR_READ=10;
	public short  ERR_WRITE=11;
	public short  ERR_RANDOM=12;
	public short  ERR_SEED=13;	
	public short  ERR_CALCULATE=14;		
	public short  ERR_NO_OPEN=15;	
	public short  ERR_OPEN_OVERFLOW=16;	
	public short  ERR_NOMORE=17;	
	public short  ERR_NEED_FIND=18;	
	public short  ERR_DECREASE=19;	
	
	public short  ERR_AR_BADCOMMAND=20;	
	public short  ERR_AR_UNKNOWN_OPCODE=21;
	public short  ERR_AR_WRONGBEGIN=22;	
	public short  ERR_AR_WRONG_END=23;	
	public short  ERR_AR_VALUEOVERFLOW=24;	
	public short  ERR_UNKNOWN=-1;		

	public short  ERR_RECEIVE_NULL=0x100;	
	public short  ERR_PRNPORT_BUSY=0x101;	
	
}
