----------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit----------

------------------- Folder Content List -------------------------------------

ActiveX                                API for ActiveX

C++Builder                             API for C++ Builder 6.0/2006

COM                                    API implemented by COM 

Delphi                                 API for Delphi 6/7/2005/2006/2007/2009

DEV_C++                                API for Dev C++

dotNet                                 API for Visual Studio 2003/2005/2008

Dynamic                                Dynamic libraries

Java                                   API for Java

MSSQL2000                              API for Microsoft Sql Server 2000

RealBasic                              API for RealBasic

Static                                 Static libraries 

Readme.txt                             This file