java sample 

1.Add JNetRockey4nd.jar into system environment variable CLASSPATH
2.Copy jNetRockey4ND.dll to current directory
3.Compile: javac jRockey4nd.java
4.execute: java jRockey4nd