NetROCKEY4ND FoxPro sample depends on library file Nrclient.dll. Please copy
this file to system32 folder and keep configuration file CliCfg.ini in project folder.

