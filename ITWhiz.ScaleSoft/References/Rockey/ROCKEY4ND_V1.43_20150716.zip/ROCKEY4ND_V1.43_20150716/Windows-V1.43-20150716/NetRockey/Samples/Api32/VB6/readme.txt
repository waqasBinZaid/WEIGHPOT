VB6 example
NOTICE:
You must copy NetRockey\Api32\Dynamic\NrClient.dll to local dir.