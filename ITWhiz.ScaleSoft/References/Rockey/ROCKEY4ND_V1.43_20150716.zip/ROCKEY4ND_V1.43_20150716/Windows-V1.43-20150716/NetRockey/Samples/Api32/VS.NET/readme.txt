If referenced API library file cannot be found when compiling the code, please remove the library file from the project and add it again.
