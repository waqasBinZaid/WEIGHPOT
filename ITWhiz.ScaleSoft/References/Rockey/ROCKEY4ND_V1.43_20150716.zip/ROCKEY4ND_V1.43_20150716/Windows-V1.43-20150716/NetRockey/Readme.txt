------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------


Api32             API for 32-bit Windows

Api64             API for 64-bit Windows

Docs              NetROCKEY4ND user manual

Include           Header file for NetROCKEY4ND

Sample            Sample programs

Server            Server programs. For 32-bit and 64-bit Windows 

Utilities         Useful tools including NrTest, NrMon and NrConfig

Reademe.txt       This file 