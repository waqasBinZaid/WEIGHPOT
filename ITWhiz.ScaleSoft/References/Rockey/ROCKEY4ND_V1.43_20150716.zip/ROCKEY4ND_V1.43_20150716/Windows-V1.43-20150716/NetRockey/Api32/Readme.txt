------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------


C++Builder                 API for C++ Builder

COM                        API implemented by COM 

dotNet                     API for Visual Studio 2003/2005/2008

Dynamic                    Dynamic library

Java                       API for Java

Static                     Static library for NetROCKEY4ND

Readme.txt                 This file