------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------

COM                         64-bit COM API

Dynamic                     64-bit dynamic library

Static                      64-bit static library

Readme.txt                  This file