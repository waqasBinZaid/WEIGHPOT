<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.btnSeed = New System.Windows.Forms.Button
        Me.btnRandom = New System.Windows.Forms.Button
        Me.btnWriteArith = New System.Windows.Forms.Button
        Me.btnCalc3 = New System.Windows.Forms.Button
        Me.btnCalc2 = New System.Windows.Forms.Button
        Me.btnReadUserID = New System.Windows.Forms.Button
        Me.btnReadModule = New System.Windows.Forms.Button
        Me.btnWriteUserID = New System.Windows.Forms.Button
        Me.btnWriteModule = New System.Windows.Forms.Button
        Me.btnCalc1 = New System.Windows.Forms.Button
        Me.btnDecModule = New System.Windows.Forms.Button
        Me.btnReadMomory = New System.Windows.Forms.Button
        Me.btnWriteMemory = New System.Windows.Forms.Button
        Me.btnCloseAll = New System.Windows.Forms.Button
        Me.btnOpenAll = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(32, 75)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(488, 88)
        Me.TextBox1.TabIndex = 39
        Me.TextBox1.Text = "TextBox1"
        Me.TextBox1.WordWrap = False
        '
        'btnSeed
        '
        Me.btnSeed.Location = New System.Drawing.Point(160, 339)
        Me.btnSeed.Name = "btnSeed"
        Me.btnSeed.Size = New System.Drawing.Size(112, 23)
        Me.btnSeed.TabIndex = 38
        Me.btnSeed.Text = "Transform Number"
        '
        'btnRandom
        '
        Me.btnRandom.Location = New System.Drawing.Point(32, 339)
        Me.btnRandom.Name = "btnRandom"
        Me.btnRandom.Size = New System.Drawing.Size(112, 23)
        Me.btnRandom.TabIndex = 37
        Me.btnRandom.Text = "Random Number"
        '
        'btnWriteArith
        '
        Me.btnWriteArith.Location = New System.Drawing.Point(32, 299)
        Me.btnWriteArith.Name = "btnWriteArith"
        Me.btnWriteArith.Size = New System.Drawing.Size(112, 23)
        Me.btnWriteArith.TabIndex = 36
        Me.btnWriteArith.Text = "Write Arithmetic"
        '
        'btnCalc3
        '
        Me.btnCalc3.Location = New System.Drawing.Point(416, 299)
        Me.btnCalc3.Name = "btnCalc3"
        Me.btnCalc3.Size = New System.Drawing.Size(112, 23)
        Me.btnCalc3.TabIndex = 35
        Me.btnCalc3.Text = "Calculate3"
        '
        'btnCalc2
        '
        Me.btnCalc2.Location = New System.Drawing.Point(288, 299)
        Me.btnCalc2.Name = "btnCalc2"
        Me.btnCalc2.Size = New System.Drawing.Size(112, 23)
        Me.btnCalc2.TabIndex = 34
        Me.btnCalc2.Text = "Calculate2"
        '
        'btnReadUserID
        '
        Me.btnReadUserID.Location = New System.Drawing.Point(160, 259)
        Me.btnReadUserID.Name = "btnReadUserID"
        Me.btnReadUserID.Size = New System.Drawing.Size(112, 23)
        Me.btnReadUserID.TabIndex = 33
        Me.btnReadUserID.Text = "Read UserID"
        '
        'btnReadModule
        '
        Me.btnReadModule.Location = New System.Drawing.Point(160, 219)
        Me.btnReadModule.Name = "btnReadModule"
        Me.btnReadModule.Size = New System.Drawing.Size(112, 23)
        Me.btnReadModule.TabIndex = 32
        Me.btnReadModule.Text = "Read Module"
        '
        'btnWriteUserID
        '
        Me.btnWriteUserID.Location = New System.Drawing.Point(32, 259)
        Me.btnWriteUserID.Name = "btnWriteUserID"
        Me.btnWriteUserID.Size = New System.Drawing.Size(112, 23)
        Me.btnWriteUserID.TabIndex = 31
        Me.btnWriteUserID.Text = "Write UserID"
        '
        'btnWriteModule
        '
        Me.btnWriteModule.Location = New System.Drawing.Point(32, 219)
        Me.btnWriteModule.Name = "btnWriteModule"
        Me.btnWriteModule.Size = New System.Drawing.Size(112, 23)
        Me.btnWriteModule.TabIndex = 30
        Me.btnWriteModule.Text = "Write Module"
        '
        'btnCalc1
        '
        Me.btnCalc1.Location = New System.Drawing.Point(160, 299)
        Me.btnCalc1.Name = "btnCalc1"
        Me.btnCalc1.Size = New System.Drawing.Size(112, 23)
        Me.btnCalc1.TabIndex = 29
        Me.btnCalc1.Text = "Calculate1"
        '
        'btnDecModule
        '
        Me.btnDecModule.Location = New System.Drawing.Point(288, 219)
        Me.btnDecModule.Name = "btnDecModule"
        Me.btnDecModule.Size = New System.Drawing.Size(112, 23)
        Me.btnDecModule.TabIndex = 28
        Me.btnDecModule.Text = "Decrease Module"
        '
        'btnReadMomory
        '
        Me.btnReadMomory.Location = New System.Drawing.Point(160, 179)
        Me.btnReadMomory.Name = "btnReadMomory"
        Me.btnReadMomory.Size = New System.Drawing.Size(112, 23)
        Me.btnReadMomory.TabIndex = 27
        Me.btnReadMomory.Text = "Read Memory"
        '
        'btnWriteMemory
        '
        Me.btnWriteMemory.Location = New System.Drawing.Point(32, 179)
        Me.btnWriteMemory.Name = "btnWriteMemory"
        Me.btnWriteMemory.Size = New System.Drawing.Size(112, 23)
        Me.btnWriteMemory.TabIndex = 26
        Me.btnWriteMemory.Text = "Write Memory"
        '
        'btnCloseAll
        '
        Me.btnCloseAll.Location = New System.Drawing.Point(288, 35)
        Me.btnCloseAll.Name = "btnCloseAll"
        Me.btnCloseAll.Size = New System.Drawing.Size(232, 23)
        Me.btnCloseAll.TabIndex = 25
        Me.btnCloseAll.Text = "Close All Rockey4ND Dongles"
        '
        'btnOpenAll
        '
        Me.btnOpenAll.Location = New System.Drawing.Point(32, 35)
        Me.btnOpenAll.Name = "btnOpenAll"
        Me.btnOpenAll.Size = New System.Drawing.Size(240, 23)
        Me.btnOpenAll.TabIndex = 24
        Me.btnOpenAll.Text = "Open All Rockey4ND Dongles"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(560, 397)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnSeed)
        Me.Controls.Add(Me.btnRandom)
        Me.Controls.Add(Me.btnWriteArith)
        Me.Controls.Add(Me.btnCalc3)
        Me.Controls.Add(Me.btnCalc2)
        Me.Controls.Add(Me.btnReadUserID)
        Me.Controls.Add(Me.btnReadModule)
        Me.Controls.Add(Me.btnWriteUserID)
        Me.Controls.Add(Me.btnWriteModule)
        Me.Controls.Add(Me.btnCalc1)
        Me.Controls.Add(Me.btnDecModule)
        Me.Controls.Add(Me.btnReadMomory)
        Me.Controls.Add(Me.btnWriteMemory)
        Me.Controls.Add(Me.btnCloseAll)
        Me.Controls.Add(Me.btnOpenAll)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents btnSeed As System.Windows.Forms.Button
    Friend WithEvents btnRandom As System.Windows.Forms.Button
    Friend WithEvents btnWriteArith As System.Windows.Forms.Button
    Friend WithEvents btnCalc3 As System.Windows.Forms.Button
    Friend WithEvents btnCalc2 As System.Windows.Forms.Button
    Friend WithEvents btnReadUserID As System.Windows.Forms.Button
    Friend WithEvents btnReadModule As System.Windows.Forms.Button
    Friend WithEvents btnWriteUserID As System.Windows.Forms.Button
    Friend WithEvents btnWriteModule As System.Windows.Forms.Button
    Friend WithEvents btnCalc1 As System.Windows.Forms.Button
    Friend WithEvents btnDecModule As System.Windows.Forms.Button
    Friend WithEvents btnReadMomory As System.Windows.Forms.Button
    Friend WithEvents btnWriteMemory As System.Windows.Forms.Button
    Friend WithEvents btnCloseAll As System.Windows.Forms.Button
    Friend WithEvents btnOpenAll As System.Windows.Forms.Button

End Class
