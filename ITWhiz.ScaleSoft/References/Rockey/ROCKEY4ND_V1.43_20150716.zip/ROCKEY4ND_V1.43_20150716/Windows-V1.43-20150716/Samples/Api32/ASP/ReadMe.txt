ASP samples

register the COM\Rockey4NDCom.dll by regsvr32.exe