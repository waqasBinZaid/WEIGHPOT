
PHP Sample for Rockey4ND

Please use command:

regsvr32 Rockey4NDCom.dll

to register the Rockey4ND COM component first


