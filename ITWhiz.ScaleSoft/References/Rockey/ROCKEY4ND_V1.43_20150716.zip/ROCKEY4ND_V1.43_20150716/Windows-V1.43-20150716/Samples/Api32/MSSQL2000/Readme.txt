SQL2000 example
Firstly, install extended process xp_Rockey4ND
and run sample next