namespace sample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.btnSeed = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnWriteArith = new System.Windows.Forms.Button();
            this.btnCalc3 = new System.Windows.Forms.Button();
            this.btnCalc2 = new System.Windows.Forms.Button();
            this.btnReadUserID = new System.Windows.Forms.Button();
            this.btnReadModule = new System.Windows.Forms.Button();
            this.btnWriteUserID = new System.Windows.Forms.Button();
            this.btnWriteModule = new System.Windows.Forms.Button();
            this.btnCalc1 = new System.Windows.Forms.Button();
            this.btnDecModule = new System.Windows.Forms.Button();
            this.btnReadMomory = new System.Windows.Forms.Button();
            this.btnWriteMemory = new System.Windows.Forms.Button();
            this.btnCloseAll = new System.Windows.Forms.Button();
            this.btnOpenAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(76, 117);
            this.TextBox1.Multiline = true;
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.ReadOnly = true;
            this.TextBox1.Size = new System.Drawing.Size(406, 81);
            this.TextBox1.TabIndex = 55;
            this.TextBox1.Text = "TextBox1";
            this.TextBox1.WordWrap = false;
            // 
            // btnSeed
            // 
            this.btnSeed.Location = new System.Drawing.Point(182, 362);
            this.btnSeed.Name = "btnSeed";
            this.btnSeed.Size = new System.Drawing.Size(94, 21);
            this.btnSeed.TabIndex = 54;
            this.btnSeed.Text = "Transform Number";
            this.btnSeed.Click += new System.EventHandler(this.btnSeed_Click);
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(76, 362);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(93, 21);
            this.btnRandom.TabIndex = 53;
            this.btnRandom.Text = "Random Number";
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // btnWriteArith
            // 
            this.btnWriteArith.Location = new System.Drawing.Point(76, 325);
            this.btnWriteArith.Name = "btnWriteArith";
            this.btnWriteArith.Size = new System.Drawing.Size(93, 21);
            this.btnWriteArith.TabIndex = 52;
            this.btnWriteArith.Text = "Write Arithmetic";
            this.btnWriteArith.Click += new System.EventHandler(this.btnWriteArith_Click);
            // 
            // btnCalc3
            // 
            this.btnCalc3.Location = new System.Drawing.Point(396, 325);
            this.btnCalc3.Name = "btnCalc3";
            this.btnCalc3.Size = new System.Drawing.Size(93, 21);
            this.btnCalc3.TabIndex = 51;
            this.btnCalc3.Text = "Calculate3";
            this.btnCalc3.Click += new System.EventHandler(this.btnCalc3_Click);
            // 
            // btnCalc2
            // 
            this.btnCalc2.Location = new System.Drawing.Point(289, 325);
            this.btnCalc2.Name = "btnCalc2";
            this.btnCalc2.Size = new System.Drawing.Size(93, 21);
            this.btnCalc2.TabIndex = 50;
            this.btnCalc2.Text = "Calculate2";
            this.btnCalc2.Click += new System.EventHandler(this.btnCalc2_Click);
            // 
            // btnReadUserID
            // 
            this.btnReadUserID.Location = new System.Drawing.Point(182, 287);
            this.btnReadUserID.Name = "btnReadUserID";
            this.btnReadUserID.Size = new System.Drawing.Size(94, 22);
            this.btnReadUserID.TabIndex = 49;
            this.btnReadUserID.Text = "Read UserID";
            this.btnReadUserID.Click += new System.EventHandler(this.btnReadUserID_Click);
            // 
            // btnReadModule
            // 
            this.btnReadModule.Location = new System.Drawing.Point(182, 250);
            this.btnReadModule.Name = "btnReadModule";
            this.btnReadModule.Size = new System.Drawing.Size(94, 22);
            this.btnReadModule.TabIndex = 48;
            this.btnReadModule.Text = "Read Module";
            this.btnReadModule.Click += new System.EventHandler(this.btnReadModule_Click);
            // 
            // btnWriteUserID
            // 
            this.btnWriteUserID.Location = new System.Drawing.Point(76, 287);
            this.btnWriteUserID.Name = "btnWriteUserID";
            this.btnWriteUserID.Size = new System.Drawing.Size(93, 22);
            this.btnWriteUserID.TabIndex = 47;
            this.btnWriteUserID.Text = "Write UserID";
            this.btnWriteUserID.Click += new System.EventHandler(this.btnWriteUserID_Click);
            // 
            // btnWriteModule
            // 
            this.btnWriteModule.Location = new System.Drawing.Point(76, 250);
            this.btnWriteModule.Name = "btnWriteModule";
            this.btnWriteModule.Size = new System.Drawing.Size(93, 22);
            this.btnWriteModule.TabIndex = 46;
            this.btnWriteModule.Text = "Write Module";
            this.btnWriteModule.Click += new System.EventHandler(this.btnWriteModule_Click);
            // 
            // btnCalc1
            // 
            this.btnCalc1.Location = new System.Drawing.Point(182, 325);
            this.btnCalc1.Name = "btnCalc1";
            this.btnCalc1.Size = new System.Drawing.Size(94, 21);
            this.btnCalc1.TabIndex = 45;
            this.btnCalc1.Text = "Calculate1";
            this.btnCalc1.Click += new System.EventHandler(this.btnCalc1_Click);
            // 
            // btnDecModule
            // 
            this.btnDecModule.Location = new System.Drawing.Point(289, 250);
            this.btnDecModule.Name = "btnDecModule";
            this.btnDecModule.Size = new System.Drawing.Size(93, 22);
            this.btnDecModule.TabIndex = 44;
            this.btnDecModule.Text = "Decrease Module";
            this.btnDecModule.Click += new System.EventHandler(this.btnDecModule_Click);
            // 
            // btnReadMomory
            // 
            this.btnReadMomory.Location = new System.Drawing.Point(182, 213);
            this.btnReadMomory.Name = "btnReadMomory";
            this.btnReadMomory.Size = new System.Drawing.Size(94, 22);
            this.btnReadMomory.TabIndex = 43;
            this.btnReadMomory.Text = "Read Memory";
            this.btnReadMomory.Click += new System.EventHandler(this.btnReadMomory_Click);
            // 
            // btnWriteMemory
            // 
            this.btnWriteMemory.Location = new System.Drawing.Point(76, 213);
            this.btnWriteMemory.Name = "btnWriteMemory";
            this.btnWriteMemory.Size = new System.Drawing.Size(93, 22);
            this.btnWriteMemory.TabIndex = 42;
            this.btnWriteMemory.Text = "Write Memory";
            this.btnWriteMemory.Click += new System.EventHandler(this.btnWriteMemory_Click);
            // 
            // btnCloseAll
            // 
            this.btnCloseAll.Location = new System.Drawing.Point(289, 79);
            this.btnCloseAll.Name = "btnCloseAll";
            this.btnCloseAll.Size = new System.Drawing.Size(193, 22);
            this.btnCloseAll.TabIndex = 41;
            this.btnCloseAll.Text = "Close All Rockey4ND Dongles";
            this.btnCloseAll.Click += new System.EventHandler(this.btnCloseAll_Click);
            // 
            // btnOpenAll
            // 
            this.btnOpenAll.Location = new System.Drawing.Point(76, 79);
            this.btnOpenAll.Name = "btnOpenAll";
            this.btnOpenAll.Size = new System.Drawing.Size(200, 22);
            this.btnOpenAll.TabIndex = 40;
            this.btnOpenAll.Text = "Open All Rockey4ND Dongles";
            this.btnOpenAll.Click += new System.EventHandler(this.btnOpenAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 463);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.btnSeed);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.btnWriteArith);
            this.Controls.Add(this.btnCalc3);
            this.Controls.Add(this.btnCalc2);
            this.Controls.Add(this.btnReadUserID);
            this.Controls.Add(this.btnReadModule);
            this.Controls.Add(this.btnWriteUserID);
            this.Controls.Add(this.btnWriteModule);
            this.Controls.Add(this.btnCalc1);
            this.Controls.Add(this.btnDecModule);
            this.Controls.Add(this.btnReadMomory);
            this.Controls.Add(this.btnWriteMemory);
            this.Controls.Add(this.btnCloseAll);
            this.Controls.Add(this.btnOpenAll);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Button btnSeed;
        internal System.Windows.Forms.Button btnRandom;
        internal System.Windows.Forms.Button btnWriteArith;
        internal System.Windows.Forms.Button btnCalc3;
        internal System.Windows.Forms.Button btnCalc2;
        internal System.Windows.Forms.Button btnReadUserID;
        internal System.Windows.Forms.Button btnReadModule;
        internal System.Windows.Forms.Button btnWriteUserID;
        internal System.Windows.Forms.Button btnWriteModule;
        internal System.Windows.Forms.Button btnCalc1;
        internal System.Windows.Forms.Button btnDecModule;
        internal System.Windows.Forms.Button btnReadMomory;
        internal System.Windows.Forms.Button btnWriteMemory;
        internal System.Windows.Forms.Button btnCloseAll;
        internal System.Windows.Forms.Button btnOpenAll;
    }
}

