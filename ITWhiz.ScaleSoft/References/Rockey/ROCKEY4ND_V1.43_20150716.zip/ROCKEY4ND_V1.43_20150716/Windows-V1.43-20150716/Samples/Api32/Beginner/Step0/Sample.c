#include <windows.h>
#include <stdio.h>

void main()
{
	// Anyone begin from here.
	printf("Hello World!\n");
}
