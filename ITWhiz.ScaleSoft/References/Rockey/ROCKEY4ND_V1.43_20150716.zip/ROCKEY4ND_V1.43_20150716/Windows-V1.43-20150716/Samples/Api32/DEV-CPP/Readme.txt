Usage:
In Project properties->parameters->linker,add Rockey4ND.a static library.