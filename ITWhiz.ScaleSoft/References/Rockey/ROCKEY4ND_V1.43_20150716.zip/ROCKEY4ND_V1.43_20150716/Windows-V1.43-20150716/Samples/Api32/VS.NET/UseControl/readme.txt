To successfully compile programs, please make sure to copy the R4ND_VS2005_Control.dll to each sample program folder.
Pleases copy Rockey4NDControl.dll for VS2003 sample only.
