BCB6 example
Please use the liberary in \Api32\C++Builder\BCB6\Rockey4ND.lib