Rockey4ND dongle Java for Win32 description


file description:
   Rockey4nd.class  driver's Java interface
   jRockey4ND.dll    driver's DLL
   jRockey4nd.java  java interface (API) sample
   
manual:
 this sample works with Rockey4nd.dll. append the path of Rockey4nd.class into CLASSPATH enviroment variable. Put jRockey4ND.dll into system directroy. (system in Win9X and system32 in WinNT).
 
		Feitian Technologies. Co., Ltd.
	
  

