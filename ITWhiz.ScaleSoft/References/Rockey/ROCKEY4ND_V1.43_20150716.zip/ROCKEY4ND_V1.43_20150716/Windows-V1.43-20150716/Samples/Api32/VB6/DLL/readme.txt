VB6 example
NOTICE:
You must copy ..\api32\Dynamic\Rockey4ND.dll to local dir.