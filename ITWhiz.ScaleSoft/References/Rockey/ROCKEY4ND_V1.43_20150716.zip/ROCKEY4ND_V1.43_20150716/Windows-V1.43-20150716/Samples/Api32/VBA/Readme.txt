VBA Sample for MS Access 

This sample demostrate how to invoke
Rockey's DLL Api in VBA.
Before you run this sample,be sure
the Rockey4ND.DLL is under your system
directory.
