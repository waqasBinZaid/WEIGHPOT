BCB2006 example

Please use the liberary in \api32\C++Builder\BCB2006\Rockey4ND.lib