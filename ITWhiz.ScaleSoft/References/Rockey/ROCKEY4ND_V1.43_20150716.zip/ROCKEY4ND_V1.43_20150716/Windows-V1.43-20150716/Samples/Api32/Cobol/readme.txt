Micro Focus Visual Object Cobol (32 Bits) Sample

Please place the Rockey4ND.dll to the sample folder

