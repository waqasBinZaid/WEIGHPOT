------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------


C                      C language sample program

MFC                    MFC based smaple program 

Rockey4_ND_64.h        32-bit header file

Rockey4ND.lib          Static library

Readme.txt             This file