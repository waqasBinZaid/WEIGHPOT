// stdafx.cpp : source file that includes just the standard includes
// VC2008_CLR_UseControl_Sample.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


