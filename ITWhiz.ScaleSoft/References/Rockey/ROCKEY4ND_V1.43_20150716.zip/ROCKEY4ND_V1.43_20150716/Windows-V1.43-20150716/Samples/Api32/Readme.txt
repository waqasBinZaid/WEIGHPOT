------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------


ASM                 Sample program for assembly language

ASP                 Sample program for ASP

Beginner            Sample programs with using C language to show how to                          program step by step

C++Builder          Sample programs for C++ Builder

Cobol               Sample program for Cobol

Delphi              Sample programs for Delphi 

DEV-CPP             Sample program for Dev C++

Fortran             Sample program for Fortran

FoxPro              Sample program for FoxPro

Java                Sample program for Java

JavaScript          Sample program for JavaScript

LabView             Sample program for LabView

MSSQL2000           Sample programs for Microsoft SQL server 2000 

Oracle              Sample program for Oracle

Perl                Sample program for Perl

PHP                 Sample program for PHP

PowerBuilder        Sample programs for PowerBuilder

Readme.txt          This file

RealBasic           Sample program for RealBasic

VB6                 Sample programs for VB6

VBA                 Sample program for VBA

VBScript            Sample program for VBScript

VC                  Sample programs for VC

VS.NET              Sample programs for Visual Studio
