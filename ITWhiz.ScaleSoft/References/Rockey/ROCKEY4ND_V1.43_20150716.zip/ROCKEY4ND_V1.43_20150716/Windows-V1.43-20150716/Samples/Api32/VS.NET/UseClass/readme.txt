To successfully compile programs, please make sure to copy the r4nd_class.dll to each sample program folder.
Pleases copy Rockey4NDClass.dll for VS2003 sample only.
