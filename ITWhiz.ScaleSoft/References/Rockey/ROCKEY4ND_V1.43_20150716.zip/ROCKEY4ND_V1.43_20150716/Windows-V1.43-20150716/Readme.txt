------------------ROCKEY4ND/NetROCKEY4ND Software Developer's Kit------------


---------------------------Folder Content List-------------------------------

Api32                  ROCKEY4ND API for 32-bit Windows

Api64                  ROCKEY4ND API for 64-bit Windows

Docs                    ROCKEY4ND User manuals

Driver For Win98       ROCKEY4ND Driver for windows 98

Include                Header files for 32-bit and 64-bit Windows 

NetROCKEY              SDK for NetRockey

Samples                ROCKEY4ND sample programs

Utilities              ROCKEY4ND utlities, including Editor tool and Envelope


Readme.txt             This file