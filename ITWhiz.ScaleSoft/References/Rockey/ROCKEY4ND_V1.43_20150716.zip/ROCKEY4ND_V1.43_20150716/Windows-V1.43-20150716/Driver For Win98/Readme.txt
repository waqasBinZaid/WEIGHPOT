Description:

Driver need to be installed under win98 and windows me. It can be found in Windows instalation CD which is provided by Microsoft.

1.HidClass.sys
2.HidHub.sys
3.Hidparse.sys