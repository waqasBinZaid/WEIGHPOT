***********************************************************************
*                                                                     *
*                           File Directory                            *
*                                                                     *
***********************************************************************


<Tools>----------------------------------------------- ROCKEY7.NET Tool
    <Redispose>------------------------------------------ Redeploy tool
	sn.exe------------------------------------------- Redeploy tool
    <Help>---------------------------------------------------- Help DOC

    ClientUpdateTool.exe--------------------- Remote Update Client Tool
    DeveloperUpdateTool.exe---------- ROCKEY7.NET Developer Update Tool
    InitializingTool.exe----------------- ROCKEY7.NET Initializing Tool
    ProducingTool.exe----------------------- ROCKEY7.NET Producing Tool
    R7.NET_Env.exe------------------------------ ROCKEY7.NET Shell Tool
    R7RunTime.Dll-------------------------- ROCKEY7.NET Runtime Library
    
<Documents>--------------------------------------- ROCKEY7.NET Help DOC
<Drivers>---------------------------- ROCKEY7.NET USB Card Reader Drive
    <x86>---------------------- ROCKEY7.NET USB Card Reader WIN32 Drive
	dpinst.exe ----------------------------------Installation files
	usbccid.CAT -------------------------------------Signature file
	usbccid.inf --------------------------------------------Profile
	usbccid.sys ----------------------------------------Driver File
    <x64>---------------------- ROCKEY7.NET USB Card Reader WIN64 Drive
	ccid_x64.exe ---------------------------------------------Drive
	dpinst.exe ----------------------------------Installation files
	usbccid.CAT -------------------------------------Signature file
	usbccid.inf --------------------------------------------Profile
	usbccid.sys ----------------------------------------Driver File